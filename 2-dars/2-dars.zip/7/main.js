import { toUpperCase, toLowerCase } from "./strings.js";

const text = "Assalomu Alaykum";

console.log(toUpperCase(text));
console.log(toLowerCase(text));
