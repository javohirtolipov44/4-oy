import { add, subtraction } from "./numbers.js";

add(5, 9);
subtraction(2, 6);
