export function add(a, b) {
  console.log(a + b);
}
export function subtraction(a, b) {
  console.log(a - b);
}
