import { greet } from "./greet.js";

greet("Ali");
