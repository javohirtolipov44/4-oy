export function greet(name) {
  console.log(`Salom, ${name}!`);
}
