import { array } from "./arrays.js";

array.forEach((item) => {
  console.log(item);
});
