export const name = "Javohir";
export const age = 25;
