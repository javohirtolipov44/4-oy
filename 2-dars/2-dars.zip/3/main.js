import { name, age } from "./person.js";

console.log(`${name} ${age} yoshda`);
