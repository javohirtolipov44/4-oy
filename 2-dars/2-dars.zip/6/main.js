import { add, subtract, multiply, divide } from "./calculator.js";

console.log(add(5, 3));
console.log(subtract(5, 3));
console.log(multiply(5, 3));
console.log(divide(5, 3));
console.log(divide(5, 0));
