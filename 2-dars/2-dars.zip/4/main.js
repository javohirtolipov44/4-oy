import student from "./student.js";

console.log(
  `Ism: ${student.first_name},\nFamiliya: ${student.last_name},\nMillati: ${student.country},\nYoshi: ${student.age}`
);
