const obj = {
  first_name: "Javohir",
  last_name: "Tolipov",
  country: "Uzbekistan",
  age: 25,
};

export default obj;
