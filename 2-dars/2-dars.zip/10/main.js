import { username, age } from "./validator.js";

const username1 = "Ali";
const username2 = "Al";
const age1 = 25;
const age2 = 17;

console.log(username(username1));
console.log(username(username2));
console.log(age(age1));
console.log(age(age2));
