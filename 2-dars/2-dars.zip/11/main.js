import { randomNumber, randomElement } from "./random.js";

const number = randomNumber();
console.log("Tasodifiy son:", number);

const colors = ["red", "green", "blue", "yellow", "purple"];
const randomColor = randomElement(colors);
console.log("Tasodifiy rang:", randomColor);
