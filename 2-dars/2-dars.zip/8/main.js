import { PI, MAX_USERS, API_URL } from "./constants.js";

console.log(`PI: ${PI}`);
console.log(`Maksimal foydalanuvchilar soni: ${MAX_USERS}`);
console.log(`API URL: ${API_URL}`);
