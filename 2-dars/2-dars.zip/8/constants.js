export const PI = 3.14159;
export const MAX_USERS = 100;
export const API_URL = "https://api.example.com";
