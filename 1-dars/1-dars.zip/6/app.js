function toUpperCase(str) {
  return str.toUpperCase();
}

console.log(toUpperCase("hello world"));
