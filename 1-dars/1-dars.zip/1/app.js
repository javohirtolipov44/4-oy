function reverseArray(arr) {
  return arr.reverse();
}

console.log(reverseArray([1, 2, 3, 4]));
