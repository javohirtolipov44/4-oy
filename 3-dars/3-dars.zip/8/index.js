import path from "node:path";

const filePath = path.join("papka", "subfolder", "rasm.jpg");

console.log("Fayl manzili:", filePath);
