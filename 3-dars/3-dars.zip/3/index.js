import os from "node:os";

const userInfo = os.userInfo();

console.log(userInfo.username);
