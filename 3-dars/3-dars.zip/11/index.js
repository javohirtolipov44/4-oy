const url = new URL("https://www.example.com");

const protocolName = url.protocol;

console.log(protocolName);
