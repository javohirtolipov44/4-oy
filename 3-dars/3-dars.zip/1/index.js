import os from "node:os";

const platform = os.platform();

console.log("Operatsion tizim:", platform);
