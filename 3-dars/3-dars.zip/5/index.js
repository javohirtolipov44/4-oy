import path from "node:path";

const filePath = "papka/subfolder/rasm.jpg";

const fileName = path.basename(filePath);

console.log("Fayl nomi:", fileName);
