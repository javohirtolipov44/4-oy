import path from "node:path";

const filePath = "papka/subfolder/rasm.jpg";

const extName = path.extname(filePath);

console.log("Fayl kengaytmasi:", extName);
