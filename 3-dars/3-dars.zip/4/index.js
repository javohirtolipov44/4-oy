import os from "node:os";

const CPU = os.cpus();

console.log(`Yadrolar soni: ${CPU.length} ta`);
